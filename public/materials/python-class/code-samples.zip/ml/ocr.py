# ==================== Import Library ====================
import cv2
import pytesseract
from PIL import Image, ImageDraw, ImageFont
import numpy as np

print("📷 โปรแกรมอ่านข้อความจากรูปภาพ + วาดกรอบ")
print("="*60)

# ==================== ตั้งค่า Tesseract ====================

# สำหรับ Windows: บอกที่อยู่ Tesseract
# ⚠️ ถ้าใช้ Mac/Linux ให้ comment (#) บรรทัดนี้ออก
# pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'

# ==================== อ่านรูปจากไฟล์ ====================

# ชื่อไฟล์รูปที่ต้องการอ่าน
filename = 'receipt_th.png'  # ← เปลี่ยนเป็นชื่อรูปของคุณ

print(f"\n📖 กำลังอ่านไฟล์: {filename}")

try:
    image = cv2.imread(filename)

    if image is None:
        print(f"❌ ไม่พบไฟล์ {filename}")
        print("\n💡 คำแนะนำ:")
        print("   1. ตรวจสอบว่าชื่อไฟล์ถูกต้อง")
        print("   2. ตรวจสอบว่ารูปอยู่ในโฟลเดอร์เดียวกับไฟล์ Python")
        print("   3. ตรวจสอบนามสกุลไฟล์ (.jpg, .png, .jpeg)")
        exit()

    print("✅ อ่านรูปสำเร็จ")
    print(f"   ขนาดรูป: {image.shape[1]} × {image.shape[0]} พิกเซล")

except Exception as e:
    print(f"❌ เกิดข้อผิดพลาด: {e}")
    exit()

# ==================== ประมวลผลรูป ====================

print("\n🔄 กำลังประมวลผลรูป...")

gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
_, thresh = cv2.threshold(gray, 127, 255, cv2.THRESH_BINARY)

print("✅ ประมวลผลเสร็จสิ้น")
print("   1. แปลงเป็นภาพเทา ✓")
print("   2. ปรับความคมชัด ✓")

# ==================== ใช้ Tesseract อ่านข้อความ ====================

print("\n🔍 กำลังอ่านข้อความด้วย Tesseract OCR...")

lang = 'tha+eng'  # ← เปลี่ยนเป็น 'tha' หรือ 'tha+eng' ได้

text = pytesseract.image_to_string(thresh, lang=lang)
data = pytesseract.image_to_data(thresh, output_type=pytesseract.Output.DICT, lang=lang)

# ==================== แสดงผลลัพธ์ ====================

print("\n" + "="*60)
print("📝 ข้อความที่อ่านได้:")
print("="*60)

if text.strip():
    print(text)

    word_count = len([t for i, t in enumerate(data['text'])
                      if int(data['conf'][i]) > 0 and t.strip()])

    print(f"\n📊 สถิติ:")
    print(f"   - พบคำทั้งหมด: {word_count} คำ")
    print(f"   - ภาษาที่ใช้: {lang}")

else:
    print("❌ ไม่พบข้อความ")
    print("\n💡 คำแนะนำ:")
    print("   1. ตรวจสอบว่ารูปมีตัวอักษรชัดเจน")
    print("   2. ลองเปลี่ยนภาษา (eng, tha, tha+eng)")
    print("   3. ลองรูปที่มีตัวหนาๆ ชัดๆ")

print("="*60)

# ==================== วาดกรอบรอบข้อความ ====================

print("\n🎨 กำลังวาดกรอบรอบข้อความ...")

image_with_boxes = image.copy()
box_count = 0

# แปลง OpenCV image (BGR) เป็น PIL Image (RGB) เพื่อวาดข้อความภาษาไทย
image_rgb = cv2.cvtColor(image_with_boxes, cv2.COLOR_BGR2RGB)
pil_image = Image.fromarray(image_rgb)
draw = ImageDraw.Draw(pil_image)

# โหลดฟอนต์ภาษาไทย (ใช้ฟอนต์ระบบ)
try:
    # ลองใช้ฟอนต์ภาษาไทยของระบบ Mac
    font = ImageFont.truetype("/System/Library/Fonts/Supplemental/Thonburi.ttc", 20)
except:
    try:
        # ถ้าไม่มี ลองใช้ฟอนต์อื่น
        font = ImageFont.truetype("/Library/Fonts/Arial Unicode.ttf", 20)
    except:
        # ถ้าไม่มีฟอนต์ ใช้ฟอนต์ default
        font = ImageFont.load_default()
        print("⚠️  ไม่พบฟอนต์ภาษาไทย ใช้ฟอนต์ default (อาจแสดงผลไม่ถูกต้อง)")

for i in range(len(data['text'])):
    if int(data['conf'][i]) > 50:
        detected_text = data['text'][i]

        if detected_text.strip():
            x = data['left'][i]
            y = data['top'][i]
            w = data['width'][i]
            h = data['height'][i]

            # วาดกรอบสี่เหลี่ยม
            draw.rectangle([(x, y), (x+w, y+h)], outline=(0, 255, 0), width=2)
            
            # วาดข้อความด้วย PIL (รองรับภาษาไทย)
            text_y = max(y - 25, 0)  # ป้องกันไม่ให้ข้อความออกนอกรูป
            draw.text((x, text_y), detected_text, font=font, fill=(0, 255, 0))

            box_count += 1

# แปลง PIL Image กลับเป็น OpenCV image
image_with_boxes = cv2.cvtColor(np.array(pil_image), cv2.COLOR_RGB2BGR)

print(f"✅ วาดกรอบเสร็จสิ้น (วาดทั้งหมด {box_count} กรอบ)")

# ==================== บันทึกรูปผลลัพธ์ ====================

output_filename = 'result_with_boxes.jpg'
cv2.imwrite(output_filename, image_with_boxes)

print(f"💾 บันทึกรูปผลลัพธ์: {output_filename}")

# # ==================== แสดงรูปเปรียบเทียบ ====================

# cv2.imshow('Original Image', image)
# cv2.imshow('Result with Boxes', image_with_boxes)

# print("\n💡 กด 'q' หรือกดปุ่มใดก็ได้เพื่อปิดหน้าต่างรูปภาพ")

# cv2.waitKey(0)
# cv2.destroyAllWindows()

# # ==================== สรุปผลลัพธ์ ====================

# print("\n" + "="*60)
# print("✅ เสร็จสิ้นทุกขั้นตอน!")
# print("="*60)
# print(f"📝 สรุปผลลัพธ์:")
# print(f"   - ไฟล์ที่อ่าน: {filename}")
# print(f"   - ภาษาที่ใช้: {lang}")
# print(f"   - จำนวนคำที่พบ: {word_count} คำ" if text.strip() else "   - ไม่พบข้อความ")
# print(f"   - จำนวนกรอบที่วาด: {box_count} กรอบ")
# print(f"   - ไฟล์ผลลัพธ์: {output_filename}")
# print("="*60)