# ==================== Import Library ====================
import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
import matplotlib

# ตั้งค่าฟอนต์สำหรับภาษาไทย
matplotlib.rcParams['font.family'] = ['Arial Unicode MS', 'Tahoma', 'DejaVu Sans']

# numpy = จัดการตัวเลขและอาเรย์
# matplotlib = วาดกราฟ
# LinearRegression = โมเดลที่ใช้หาเส้นตรง

print("🏠 โปรแกรมทำนายราคาบ้าน")
print("="*50)

# ==================== เตรียมข้อมูล ====================

# ข้อมูลขนาดบ้าน (ตารางเมตร) - INPUT (Features)
ขนาด = np.array([30, 50, 70, 90, 110])

# ข้อมูลราคาบ้าน (ล้านบาท) - OUTPUT (Labels)
ราคา = np.array([1.5, 2.5, 3.5, 4.5, 5.5])

# reshape(-1, 1) = แปลงเป็นคอลัมน์
# ทำไม: sklearn ต้องการข้อมูล 2 มิติ
# จาก [30, 50, 70] → [[30], [50], [70]]
ขนาด = ขนาด.reshape(-1, 1)

print(f"✅ เตรียมข้อมูล {len(ขนาด)} หลัง")

# ==================== สร้างและฝึกสอนโมเดล ====================

# สร้างโมเดล Linear Regression (ยังเป็นเปล่าๆ ไม่รู้อะไร)
โมเดล = LinearRegression()

# ฝึกสอนโมเดล
# .fit() = ให้โมเดลเรียนรู้จากข้อมูล
# โมเดลจะหาสูตร y = mx + b ที่เหมาะสมที่สุด
โมเดล.fit(ขนาด, ราคา)

print("✅ ฝึกสอนเสร็จ!")

# ดูสูตรที่โมเดลเรียนรู้
# coef_ = ความชัน (m)
# intercept_ = จุดตัดแกน (b)
ความชัน = โมเดล.coef_[0]
จุดตัด = โมเดล.intercept_

print(f"\n📐 สูตร: ราคา = {ความชัน:.4f} × ขนาด + {จุดตัด:.4f}")
print(f"   → บ้านใหญ่ขึ้น 1 ตร.ม. ราคาเพิ่ม {ความชัน:.4f} ล้าน")

# ==================== ทำนายบ้านใหม่ ====================

# บ้านที่ต้องการทำนาย
บ้านใหม่ = np.array([[60], [100]])

# ใช้โมเดลทำนาย
# .predict() = ใช้สูตรที่เรียนรู้มาทำนาย
ราคาทำนาย = โมเดล.predict(บ้านใหม่)

print(f"\n🔮 การทำนาย:")
print(f"   บ้าน 60 ตร.ม. = {ราคาทำนาย[0]:.2f} ล้านบาท")
print(f"   บ้าน 100 ตร.ม. = {ราคาทำนาย[1]:.2f} ล้านบาท")

# ==================== วาดกราฟ ====================

plt.figure(figsize=(10, 6))

# จุดสีน้ำเงิน = ข้อมูลจริง
# scatter = วาดจุด
plt.scatter(ขนาด, ราคา, color='blue', s=100, label='ข้อมูลจริง', zorder=3)

# เส้นสีแดง = เส้นทำนาย
# plot = วาดเส้น
plt.plot(ขนาด, โมเดล.predict(ขนาด), color='red', linewidth=2, label='เส้นทำนาย')

# จุดสีเขียว = บ้านที่ทำนาย
plt.scatter(บ้านใหม่, ราคาทำนาย, color='green', s=200, marker='*', label='ทำนาย', zorder=3)

# ตกแต่งกราฟ
plt.xlabel('ขนาดบ้าน (ตารางเมตร)', fontsize=12)
plt.ylabel('ราคาบ้าน (ล้านบาท)', fontsize=12)
plt.title('📈 โมเดล ML ทำนายราคาบ้าน', fontsize=14, fontweight='bold')
plt.legend()
plt.grid(True, alpha=0.3)

# แสดงกราฟ
plt.tight_layout()
plt.show()

print("\n✅ เสร็จสิ้น!")