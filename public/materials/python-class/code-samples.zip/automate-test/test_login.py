from selenium import webdriver
from selenium.webdriver.common.by import By
import time

# สร้าง driver
driver = webdriver.Chrome()
driver.maximize_window()

# ข้อมูลสำหรับทดสอบ
TEST_URL = "https://practicetestautomation.com/practice-test-login/"
VALID_USERNAME = "student"
VALID_PASSWORD = "Password123"

# ตัวแปรตัวพิมพ์ใหญ่ = ค่าคงที่ที่ไม่เปลี่ยน

print("=" * 50)
print("เริ่มทดสอบระบบ Login/Logout")
print("=" * 50)

# ========================================
# Test Case 1: Login สำเร็จ
# ========================================
print("\n[Test Case 1] ทดสอบ Login ด้วยข้อมูลที่ถูกต้อง")
print("-" * 50)

try:
    # try = ลองทำอะไรบางอย่าง ถ้าเกิด error จะไปทำงานใน except

    # ขั้นที่ 1: เปิดหน้า Login
    print("1. เปิดหน้า Login...")
    driver.get(TEST_URL)
    time.sleep(2)

    # ขั้นที่ 2: กรอก Username
    print(f"2. กรอก Username: {VALID_USERNAME}")
    username_field = driver.find_element(By.ID, "username")
    username_field.clear()  # ลบข้อความเก่าออกก่อน (ถ้ามี)
    username_field.send_keys(VALID_USERNAME)

    # .clear() = ลบข้อความที่อยู่ในช่องออกทั้งหมด
    # ควรใช้ก่อน send_keys() เพื่อความปลอดภัย
    # f"..." = f-string สำหรับใส่ตัวแปรในข้อความ

    time.sleep(1)

    # ขั้นที่ 3: กรอก Password
    print(f"3. กรอก Password: {VALID_PASSWORD}")
    password_field = driver.find_element(By.ID, "password")
    password_field.clear()
    password_field.send_keys(VALID_PASSWORD)
    time.sleep(1)

    # ขั้นที่ 4: คลิกปุ่ม Submit
    print("4. คลิกปุ่ม Submit")
    submit_button = driver.find_element(By.ID, "submit")
    submit_button.click()

    # รอให้หน้าเว็บโหลดหลัง submit
    time.sleep(3)

    # ขั้นที่ 5: ตรวจสอบว่า Login สำเร็จจริงหรือไม่
    print("5. ตรวจสอบผลลัพธ์...")

    # ตรวจสอบ URL
    current_url = driver.current_url
    print(f"   - URL ปัจจุบัน: {current_url}")

    # driver.current_url = ดึง URL ของหน้าปัจจุบัน

    # ตรวจสอบข้อความบนหน้าเว็บ
    success_message = driver.find_element(By.TAG_NAME, "h1").text
    print(f"   - ข้อความที่แสดง: {success_message}")

    # .text = ดึงข้อความที่แสดงใน element
    # By.TAG_NAME, "h1" = หาแท็ก h1 (หัวข้อใหญ่)

    # ตรวจสอบปุ่ม Logout มีหรือไม่
    logout_button = driver.find_element(By.LINK_TEXT, "Log out")

    # By.LINK_TEXT = ค้นหาลิงก์จากข้อความที่แสดง
    # "Log out" = ข้อความในลิงก์ที่ต้องการหา

    # ถ้าเจอปุ่ม Logout และ URL ถูกต้อง = Login สำเร็จ
    if "logged-in-successfully" in current_url and logout_button:
        print("\n✓ ผลการทดสอบ: PASS (Login สำเร็จ)")
    else:
        print("\n✗ ผลการทดสอบ: FAIL (Login ไม่สำเร็จ)")

    # ถ่ายภาพหน้าจอหลัง Login สำเร็จ
    driver.save_screenshot("login_success.png")
    print("✓ บันทึกภาพหน้าจอ: login_success.png")

    time.sleep(2)

    # ขั้นที่ 6: ทดสอบ Logout
    print("\n6. ทดสอบ Logout...")
    logout_button.click()
    time.sleep(2)

    # ตรวจสอบว่ากลับมาหน้า Login แล้ว
    if TEST_URL in driver.current_url:
        print("✓ Logout สำเร็จ - กลับมาหน้า Login แล้ว")
    else:
        print("✗ Logout ไม่สำเร็จ")

    driver.save_screenshot("logout_success.png")

except Exception as e:
    # ถ้าเกิด error ใดๆ ให้แสดงข้อความและถ่ายภาพ
    print(f"\n✗ เกิดข้อผิดพลาด: {str(e)}")
    driver.save_screenshot("error_test_case_1.png")

    # Exception = ข้อผิดพลาดทุกประเภท
    # str(e) = แปลง error เป็นข้อความเพื่อแสดงผล

print("\n" + "=" * 50)

# ========================================
# Test Case 2: Login ไม่สำเร็จ (Password ผิด)
# ========================================
print("\n[Test Case 2] ทดสอบ Login ด้วย Password ผิด")
print("-" * 50)

try:
    # กลับไปหน้า Login อีกครั้ง
    driver.get(TEST_URL)
    time.sleep(2)

    print("1. กรอก Username ถูกต้อง")
    username_field = driver.find_element(By.ID, "username")
    username_field.clear()
    username_field.send_keys(VALID_USERNAME)
    time.sleep(1)

    print("2. กรอก Password ผิด: wrongpassword")
    password_field = driver.find_element(By.ID, "password")
    password_field.clear()
    password_field.send_keys("wrongpassword")

    # ใส่รหัสผ่านที่ผิดตั้งใจ เพื่อทดสอบว่าระบบจะแสดง error หรือไม่

    time.sleep(1)

    print("3. คลิกปุ่ม Submit")
    submit_button = driver.find_element(By.ID, "submit")
    submit_button.click()
    time.sleep(2)

    # ตรวจสอบว่ามีข้อความ error หรือไม่
    print("4. ตรวจสอบข้อความ error...")
    try:
        error_message = driver.find_element(By.ID, "error").text
        print(f"   - ข้อความ error: {error_message}")

        # .lower() = แปลงข้อความเป็นตัวพิมพ์เล็กทั้งหมด
        # ใช้เพื่อให้เปรียบเทียบข้อความได้ง่ายขึ้น

        if "invalid" in error_message.lower():
            print("\n✓ ผลการทดสอบ: PASS (แสดง error message ถูกต้อง)")
        else:
            print("\n✗ ผลการทดสอบ: FAIL (error message ไม่ถูกต้อง)")
    except:
        print("\n✗ ผลการทดสอบ: FAIL (ไม่พบ error message)")

    driver.save_screenshot("login_invalid_password.png")
    print("✓ บันทึกภาพหน้าจอ: login_invalid_password.png")

except Exception as e:
    print(f"\n✗ เกิดข้อผิดพลาด: {str(e)}")
    driver.save_screenshot("error_test_case_2.png")

# สรุปผลการทดสอบ
print("\n" + "=" * 50)
print("เสร็จสิ้นการทดสอบทั้งหมด")
print("=" * 50)

time.sleep(3)
driver.quit()
print("ปิดเบราว์เซอร์เรียบร้อยแล้ว")
