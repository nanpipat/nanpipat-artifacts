# นำเข้าไลบรารี่ที่ต้องใช้
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import time

# บรรทัดนี้อธิบายว่า: เราจะนำเข้า (import) เครื่องมือต่างๆ มาใช้งาน
# - webdriver = ตัวควบคุมเบราว์เซอร์
# - By = เครื่องมือสำหรับค้นหาองค์ประกอบในหน้าเว็บ
# - Keys = ชุดปุ่มพิเศษบนคีย์บอร์ด เช่น Enter, Tab, Escape
# - time = เครื่องมือสำหรับจัดการเวลา

# สร้างตัวควบคุมเบราว์เซอร์ Chrome
driver = webdriver.Chrome()

# บรรทัดนี้คือการสร้าง "หุ่นยนต์" ที่จะควบคุม Chrome ให้เรา
# driver = ตัวแปรที่เก็บ "หุ่นยนต์" ตัวนี้ไว้
# webdriver.Chrome() = สร้างหุ่นยนต์สำหรับ Chrome

# ขยายหน้าต่างเบราว์เซอร์ให้เต็มจอ
driver.maximize_window()

# driver.maximize_window() = ขยายหน้าต่างให้เต็มหน้าจอ
# ทำให้มองเห็นง่าย และป้องกันปัญหาองค์ประกอบบางตัวซ่อนอยู่

print("ขั้นตอนที่ 1: เปิดเว็บ DuckDuckGo")
driver.get("https://duckduckgo.com")

# บรรทัดนี้สั่งให้เบราว์เซอร์เปิดไปที่ DuckDuckGo
# DuckDuckGo = Search Engine ที่ไม่มี CAPTCHA และเคารพความเป็นส่วนตัว
# driver.get() = คำสั่งเปิดเว็บ

time.sleep(2)  # รอให้หน้าเว็บโหลดเสร็จ

# ทำไมต้องรอ? เพราะหน้าเว็บต้องใช้เวลาโหลด ถ้าไม่รอ Selenium
# อาจหาองค์ประกอบไม่เจอเพราะหน้าเว็บยังโหลดไม่เสร็จ
# time.sleep(2) = หยุดโปรแกรม 2 วินาที

print("ขั้นตอนที่ 2: หาช่องค้นหา")
# หาช่องค้นหาของ DuckDuckGo (มี name="q")
search_box = driver.find_element(By.NAME, "q")

# driver.find_element() = คำสั่งค้นหาองค์ประกอบ
# By.NAME = ค้นหาจากชื่อ attribute "name"
# "q" = ชื่อของช่องค้นหา DuckDuckGo (เหมือน Google)
# search_box = ตัวแปรที่เก็บองค์ประกอบที่เจอ

print("ขั้นตอนที่ 3: พิมพ์คำค้นหา")
# พิมพ์คำว่า "Selenium Python"
search_box.send_keys("Selenium Python")

# send_keys() = คำสั่งพิมพ์ข้อความลงในช่อง input
# "Selenium Python" = ข้อความที่จะพิมพ์
# เหมือนเราพิมพ์ด้วยคีย์บอร์ดจริงๆ

time.sleep(1)  # รอให้เห็นว่าพิมพ์อะไร

print("ขั้นตอนที่ 4: กดปุ่ม Enter เพื่อค้นหา")
# กด Enter เพื่อค้นหา
search_box.send_keys(Keys.RETURN)

# Keys.RETURN = ปุ่ม Enter บนคีย์บอร์ด
# เหมือนเรากด Enter หลังจากพิมพ์คำค้นหา

time.sleep(3)  # รอให้ผลการค้นหาแสดงออกมา

print("ขั้นตอนที่ 5: ตรวจสอบผลลัพธ์")
# ตรวจสอบว่ามีคำว่า "Selenium" ในหน้าผลลัพธ์หรือไม่
if "Selenium" in driver.page_source:
    print("✓ ผ่าน: พบคำว่า Selenium ในผลการค้นหา")
else:
    print("✗ ไม่ผ่าน: ไม่พบคำว่า Selenium")

# driver.page_source = ดึง HTML code ทั้งหมดของหน้าเว็บ
# "Selenium" in driver.page_source = ตรวจสอบว่ามีคำว่า Selenium หรือไม่
# if...else = เงื่อนไขเช็คผลลัพธ์

print("ขั้นตอนที่ 6: นับจำนวนผลลัพธ์")
# ลองนับจำนวนผลลัพธ์ที่แสดง
try:
    results = driver.find_elements(By.CSS_SELECTOR, "article[data-testid='result']")
    print(f"✓ พบผลการค้นหา {len(results)} รายการ")
except:
    print("⚠️ ไม่สามารถนับผลการค้นหาได้")

# find_elements() = หาองค์ประกอบหลายๆ ตัว (ใส่ s ท้าย)
# CSS_SELECTOR = ค้นหาด้วย CSS selector
# article[data-testid='result'] = ผลการค้นหาแต่ละรายการของ DuckDuckGo
# len(results) = นับจำนวนผลลัพธ์

print("ขั้นตอนที่ 7: ถ่ายภาพหน้าจอ")
# ถ่ายภาพหน้าจอเก็บไว้เป็นหลักฐาน
driver.save_screenshot("duckduckgo_search_result.png")

# save_screenshot() = ถ่ายภาพหน้าจอ
# "duckduckgo_search_result.png" = ชื่อไฟล์ที่จะบันทึก
# ไฟล์จะถูกบันทึกในโฟลเดอร์เดียวกับไฟล์ Python

print("✓ บันทึกภาพหน้าจอเรียบร้อย")

# รอ 3 วินาทีเพื่อดูผลลัพธ์
time.sleep(3)

# ปิดเบราว์เซอร์
driver.quit()

# บรรทัดนี้ปิดเบราว์เซอร์และหยุดการทำงานของ driver
# driver.quit() = ปิดเบราว์เซอร์และล้างข้อมูลทั้งหมด
# (ถ้าใช้ driver.close() จะปิดแค่แท็บปัจจุบัน)

print("เสร็จสิ้นการทดสอบ!")
print("💡 DuckDuckGo ไม่มี CAPTCHA ทำให้ทดสอบได้สะดวกกว่า Google")
