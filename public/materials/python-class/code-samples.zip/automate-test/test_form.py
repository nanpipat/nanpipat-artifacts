from selenium import webdriver
from selenium.webdriver.common.by import By
import time

# สร้าง driver
driver = webdriver.Chrome()
driver.maximize_window()

# ในตัวอย่างนี้เราจะใช้เว็บทดสอบฟอร์มจำลอง
# เป็นเว็บที่สร้างขึ้นเพื่อให้ฝึกเขียน automation test
print("เปิดเว็บฟอร์มทดสอบ")
driver.get("https://www.selenium.dev/selenium/web/web-form.html")
time.sleep(2)

# 1. กรอกช่อง Text Input
print("1. กรอกช่อง Text Input")
text_input = driver.find_element(By.ID, "my-text-id")

# By.ID = ค้นหาจาก id
# "my-text-id" = ค่า id ของช่อง text input

text_input.send_keys("สวัสดีครับ")

# send_keys() = พิมพ์ข้อความ

time.sleep(1)

# 2. กรอกช่อง Password
print("2. กรอกช่อง Password")
password_input = driver.find_element(By.NAME, "my-password")
password_input.send_keys("password123")

# ช่อง password ไม่มี id แต่มี name
# เราก็ใช้ By.NAME ค้นหาแทน

time.sleep(1)

# 3. กรอกช่อง Textarea (ช่องข้อความขนาดใหญ่)
print("3. กรอกช่อง Textarea")
textarea = driver.find_element(By.NAME, "my-textarea")
textarea.send_keys("นี่คือข้อความทดสอบ\nบรรทัดที่ 2\nบรรทัดที่ 3")

# \n = ขึ้นบรรทัดใหม่
# เหมือนเรากด Enter ในการพิมพ์ปกติ

time.sleep(1)

# 4. เลือก Dropdown
print("4. เลือกจาก Dropdown")
dropdown = driver.find_element(By.NAME, "my-select")
dropdown.click()  # คลิกเปิด dropdown

# click() = คำสั่งคลิก
# ใช้กับ button, checkbox, radio, link, dropdown ได้หมด

time.sleep(0.5)

# หาตัวเลือกที่ต้องการและคลิก
option = driver.find_element(By.CSS_SELECTOR, "option[value='2']")
option.click()

# CSS_SELECTOR = ใช้ CSS เพื่อค้นหา
# option[value='2'] = หาแท็ก option ที่มี value='2'
# [...] = หมายถึง attribute ใน CSS

time.sleep(1)

# 5. คลิก Checkbox
print("5. คลิก Checkbox")
checkbox = driver.find_element(By.ID, "my-check-2")
checkbox.click()

# checkbox.click() = คลิกเพื่อติ๊กถูก checkbox

time.sleep(1)

# 6. คลิก Radio Button
print("6. เลือก Radio Button")
radio = driver.find_element(By.ID, "my-radio-2")
radio.click()

# radio button = ปุ่มเลือกแบบเลือกได้อันเดียว
# checkbox = ติ๊กได้หลายอัน

time.sleep(1)

# 7. คลิกปุ่ม Submit
print("7. คลิกปุ่ม Submit")
submit_button = driver.find_element(By.CSS_SELECTOR, "button[type='submit']")
submit_button.click()

# button[type='submit'] = หาปุ่มที่มี type เป็น submit

time.sleep(2)

# 8. ตรวจสอบว่าส่งฟอร์มสำเร็จหรือไม่
# (หน้านี้จะไปหน้า submit confirmation)
print("8. ตรวจสอบผลลัพธ์")

if "Received!" in driver.page_source:
    print("✓ สำเร็จ: ส่งฟอร์มได้แล้ว")
else:
    print("✗ ไม่สำเร็จ: ส่งฟอร์มไม่ได้")

# "Received!" in driver.page_source = เช็คว่ามีคำว่า Received! หรือไม่

# ถ่ายภาพหน้าจอ
driver.save_screenshot("form_result.png")
print("✓ บันทึกภาพหน้าจอแล้ว")

time.sleep(3)
driver.quit()
print("เสร็จสิ้นการทดสอบฟอร์ม!")
